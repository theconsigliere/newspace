<div class="error">
	<p>
		<?php
		printf(
			__(
				'All in One WP Migration is not able to create <strong>%s</strong> file. ' .
				'Try to change permissions of the parent folder or send us an email at ' .
				'<a href="mailto:support@servmask.com">support@servmask.com</a> for assistance.',
				AI1WM_PLUGIN_NAME
			),
			AI1WM_STORAGE_INDEX
		)
		?>
	</p>
</div>
